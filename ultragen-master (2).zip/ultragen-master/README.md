# ultragen
Generates NitroType accounts and exports them as UltraType++ config files
